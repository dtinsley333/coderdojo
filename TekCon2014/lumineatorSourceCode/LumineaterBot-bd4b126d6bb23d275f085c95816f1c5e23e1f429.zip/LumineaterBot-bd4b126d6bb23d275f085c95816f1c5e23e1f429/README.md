LumineaterBot
=============

Light seeking robot.
